package com.example.imad5112_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private var user1: TextView? = null
    private var user2: TextView? = null
    private var answer: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        user1 = findViewById(R.id.enter1)
        user2 = findViewById(R.id.enter2)
        answer = findViewById(R.id.tvAnswer)

        val selectAdd = findViewById<Button>(R.id.selectAdd)
        val selectSubtract = findViewById<Button>(R.id.selectSubtract)
        val selectMultiply = findViewById<Button>(R.id.selectMultiply)
        val selectDivide = findViewById<Button>(R.id.selectDivide)
        val selectSquare = findViewById<Button>(R.id.selectSquare)
        val selectPower = findViewById<Button>(R.id.selectPower)
        val selectStatistics = findViewById<Button>(R.id.selectStatistics)

        selectAdd.setOnClickListener {
            add()
        }

        selectSubtract.setOnClickListener {
            subtract()
        }

        selectMultiply.setOnClickListener {
            multiple()
        }

        selectDivide.setOnClickListener {
            divide()
        }

        selectSquare.setOnClickListener {
            squareRoot()
        }

        selectPower.setOnClickListener {
            power()
        }

        selectStatistics.setOnClickListener {
            statistics()
        }
    }

    private fun add() {

        if (isNotEmpty()) {

            val value1 = user1?.text.toString().trim().toBigDecimal()
            val value2 = user2?.text.toString().trim().toBigDecimal()
            answer?.text = value1.add(value2).toString()
        }
    }

    private fun isNotEmpty(): Boolean {

        var a = true
        if(user1?.text.toString().trim().isEmpty()){
            user1?.error = "Required"
            a = false
        }
        if (user2?.text.toString().trim().isEmpty()){
            user2?.error = "Required"
            a= false
        }
        return a

    }

    private fun subtract(){

        if (isNotEmpty()) {

            val value1 = user1?.text.toString().trim().toBigDecimal()
            val value2 = user2?.text.toString().trim().toBigDecimal()
            answer?.text = value1.subtract(value2).toString()
        }
    }

    private fun multiple(){

        if (isNotEmpty()) {

            val value1 = user1?.text.toString().trim().toBigDecimal()
            val value2 = user2?.text.toString().trim().toBigDecimal()
            answer?.text = value1.multiply(value2).toString()
        }
    }

    private fun divide(){

        if (isNotEmpty()) {

            val value1 = user1?.text.toString().trim().toBigDecimal()
            val value2 = user2?.text.toString().trim().toBigDecimal()
            answer?.text = value1.divide(value2).toString()
        }
    }

    private fun squareRoot(){

    }

    private fun power(){

    }

    private fun statistics(){

    }
}